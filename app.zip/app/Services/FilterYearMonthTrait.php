<?php

namespace App\Services;

trait FilterYearMonthTrait
{



}
